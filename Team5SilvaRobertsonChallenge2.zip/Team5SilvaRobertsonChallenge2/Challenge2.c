#pragma config(Sensor, S4, sonar4, sonar4, sendorEV3_Ultrasonic)
#pragma config(Sensor, S1, llight, sensorEV3_color, modeEV3Color_Color)
#pragma config(Sensor, S2, rlight, sensorEV3_color, modeEV3Color_Color)
/***********************************
*    ROBOTICS CHALLENGE 2         *
*    Group #5                     *
*    Hannah Silva				  *
*    Melinda Robertson 			  *
***********************************/
//ROBOTC API:
//http://help.robotc.net/WebHelpMindstorms/index.htm#Resources/topics/LEGO_EV3/ROBOTC/Buttons/waitForButtonPress.htm

/*Motor and touch sensor indexes.*/
#define leftMotor 1 //LEFT_MOTOR
#define rightMotor 2 //RIGHT_MOTOR

#define MAXSPEED 70  //speed of opposite motor to turn
#define MINSPEED 65   //speed of motor in direction of turn
#define REGSPEED 50   //the normal speed of both motors
#define SHARPSPEED 100  //for turning a sharp corner

#define MINTURN 40 //the minimum number of cycles that the robot should be turning
#define MAXTURN 45 //the maximum number of cycles that the robot should be turning

#define iLENGTH 7   //the length of the array
#define itime 0     //the number of cycles until the next turn
#define iturn 1     //the next turn to take; right:0, left:1
#define iturntime 2 //the number of cycles to be turning
#define inumturns 3 //keeps track of how many left and right turns there are
//sensor-near: 0; w-w:1; b-b:2; w-b:3; b-w:4
#define istate  4   //the last state of the sensors
#define istatetime 5 //amount of time since last state
#define withinInch 6 //whether or not the robot is within an inch of an object
//irobot[istate] == 0
int irobot[iLENGTH]; //holds information about the robot state
int count; //how many turns it took
int check_turn; //0 = right; 1 = left


//number between 0 and 1 for the "Exponentially Weighted Moving Average.
//0 means current is 100% 1 means past results are 100%
#define ALPHA 0.7
#define ALPHA_SONAR 0.6
#define LENGTH 4	//the length of the sensor arrays
#define lastReading 0	//index of the last reading for each sensor array
#define average 1	//index of the weighted average for each sensor array
#define canread 2	//index of whether or not the thread can take new reading
//info: last reading, avg
float sensor_sonic[LENGTH];
float sensor_rlight[LENGTH];
float sensor_llight[LENGTH];

float BOUND = 10;	//set hardcoded bound if not read in through startup. 
					//If sensor value is under this, then black.
float NEAR = 5;		//set hardcoded bound for the value of within an inch
					//for the sonar sensor.

/**
 *	Returns a random value between the min and max value.
 *	
 *	min: minimum value of desired random int
 *	max: maximum value of desired random int
 *	return: random int value
 */					
int my_rand(int min, int max) {
	/*Returns a random number between the min and max.*/
	int num = (rand()%(max-min))+min;
	return abs(num);
}

/**
 *	Takes in the last reading of the light sensor and the
 *	current average and returns the weighted average
 *
 *	lr: the last reading read by the light sensor
 *	avg: the current average of the light sensor readings
 *	return: the new weighted average
 */
float weightedAvg(float lr, float avg) {
	return (lr + ALPHA * (avg-lr));
}

/**
 *	Takes in the last reading of the sonar sensor and the
 *	current average and returns the weighted average
 *
 *	lr: the last reading read by the sonar sensor
 *	avg: the current average of the sensor readings
 *	return: the new weighted average
 */
float weightedAvg_Sonar(float lr, float avg) {
	return (lr + ALPHA_SONAR * (avg-lr));
}

/**
 * Used to get the initial calibrations of the sensors.
 * First the sensor is placed over white and the center
 * button is clicked to get the value of white, then 
 * the black value is taken and the bound for the sonar
 * is last. Then an initial average is taken for each 
 * sensor.
 */
void startup() {
	while (getButtonPress(buttonAny) != 1) {
		displayBigTextLine(4, "Right: %d", sensor_rlight[lastReading]);
		displayBigTextLine(8, "Left: %d", sensor_llight[lastReading]);
	}
	eraseDisplay();
	float white = (sensor_rlight[lastReading] + sensor_llight[lastReading])/2;
	displayBigTextLine(4, "Accepted: %d", white);
	sleep(500);
	while (getButtonPress(buttonAny) != 1) {
		displayBigTextLine(4, "Right: %d", sensor_rlight[lastReading]);
		displayBigTextLine(8, "Left: %d", sensor_llight[lastReading]);
	}
	eraseDisplay();
	float black = (sensor_rlight[lastReading] + sensor_llight[lastReading])/2;
	sleep(500);
	displayBigTextLine(4, "Accepted: %d", black);
	BOUND = (white + black)/2 - 17;
	sleep(500);
	displayBigTextLine(4, "Set Bound: %d", BOUND);
	sleep(500);
	while (getButtonPress(buttonAny) != 1) {
		displayCenteredBigTextLine(4, "Dist: %3d", sensor_sonic[lastReading]);
	}
	NEAR = sensor_sonic[lastReading];
	displayBigTextLine(4, "Accepted: %d", NEAR);
	sleep(500);
	eraseDisplay();
	int i = 100;
	int sums = 0, suml = 0, sumr = 0;
	while (i) {
		sums = sums + sensor_sonic[lastReading] * pow((1-ALPHA_SONAR),i);
		suml = suml + sensor_llight[lastReading] * pow((1-ALPHA),i);
		sumr = sumr + sensor_rlight[lastReading] * pow((1-ALPHA),i);
		i = i - 1;
		sleep(20);
	}
	sensor_sonic[average] = (sums + sensor_sonic[lastReading]) * ALPHA_SONAR;
	sensor_llight[average] = (suml + sensor_llight[lastReading]) * ALPHA;
	sensor_rlight[average] = (sumr + sensor_rlight[lastReading]) * ALPHA;
	displayBigTextLine(4, "Starting...%d,", sensor_sonic[average]);
	displayBigTextLine(8, "%d, %d", sensor_llight[average], sensor_rlight[average]);
	sleep(2000);
	eraseDisplay();
}

/**
 * Resets the speed of the motors to go forward and 
 * the values for determining when to turn.
 *	
 * return: 0
 */
int reset_motor() {
	setMotorSpeed(leftMotor, REGSPEED);
	setMotorSpeed(rightMotor, REGSPEED);
	//reset time until turn
	irobot[itime] = 1;
	irobot[iturntime] = -1;
	irobot[inumturns] = 0;
	return 0;
}

/**
 * Sets the motors to turn right.
 *
 * return: 0
 */
int turn_right() {
	int speed = my_rand(MINSPEED, MAXSPEED);
	setMotorSpeed(leftMotor, speed);
	setMotorSpeed(rightMotor, speed-my_rand(10, 13));
	//reset time until stop turning
	irobot[iturntime] = my_rand(MINTURN, MAXTURN);
	irobot[inumturns] = irobot[inumturns] + 1;
	return 0;
}

/**
 * Sets the motors to turn left.
 *
 * return: 0
 */
int turn_left() {
	int speed = my_rand(MINSPEED, MAXSPEED);
	setMotorSpeed(rightMotor, speed);
	setMotorSpeed(leftMotor, speed-my_rand(10, 13));
	//reset time until stop turning
	irobot[iturntime] = my_rand(MINTURN, MAXTURN);
	irobot[inumturns] = irobot[inumturns] - 1;
	return 0;
}

/**
 * Thread for reading in sonar sensor values and computing
 * the weighted average. If the average is under 91 then it
 * means that an object has been detected. If the average is
 * under 5 then it means that the object is within an inch. 
 */
task infrasense(){
	while (true) {
		sensor_sonic[canread] = 0;
		sensor_sonic[lastReading] = SensorValue[sonar4];
		sensor_sonic[average] = weightedAvg_Sonar(sensor_sonic[lastReading], sensor_sonic[average]);
		if (sensor_sonic[average] <= 91) {
			irobot[istate] = 0;
			setLEDColor(ledGreen);
		} else
			setLEDColor(ledRed);
		if (sensor_sonic[average] <= 5)
			irobot[withinInch] = 1;
		else
			irobot[withinInch] = 0;
		sensor_sonic[canread] = 1;
		sleep(20);
	}
}

/**
 * Thread for reading in the right light sensor values and
 * computing the weighted average. 
 */
task right_lightsense(){
	while (true) {
		sensor_rlight[canread] = 0;
		sensor_rlight[lastReading] = SensorValue[rlight];
		sensor_rlight[average] = weightedAvg(sensor_rlight[lastReading], sensor_rlight[average]);
		sensor_rlight[canread] = 1;
		sleep(20);
	}
}

/**
 * Thread for reading in the left light sensor values and
 * computing the weighted average. 
 */
task left_lightsense(){
	while (true) {
		sensor_llight[canread] = 0;
		sensor_llight[lastReading] = SensorValue[llight];
		sensor_llight[average] = weightedAvg(sensor_llight[lastReading], sensor_llight[average]);
		sensor_llight[canread] = 1;
		sleep(20);
	}
}

/**
 * Sets the motor speed to given left and right powers.
 * 
 * powerL: the power to set the left motor
 * powerR: the power to set the right motor 
 */
void setMotor(int powerL, int powerR) {
	setMotorSpeed(leftMotor, powerL);
	setMotorSpeed(rightMotor, powerR);
}

/**
 * The action to perform if the sonar sensor detects
 * an object. While it sees an object, it sets the power
 * of the motor to a proportional speed based on the 
 * distance of the object away from the sonar. If the 
 * distance is within an inch away then the robot will
 * stop for 3 seconds, go backwards and then turn around.
 */
void approachObject() {
	int powers = RegSpeed + (sensor_sonic[average]/2);
	while (irobot[istate] == 0) { //if sees object
		powers = sensor_sonic[average] * 1.5;
		setMotor(powers, powers);
		if (irobot[withinInch]) {
			setMotor(0,0);
			sleep(3000);
			setMotor(-50, -50);
			sleep(1000);
			setMotor(100, -100);
			sleep(200);
		}
		sleep(100);
		if (sensor_sonic[average] > 91) {
			irobot[istate] = 1;
		}
	}
}
/**
 * The action to perform if the sonar does not detect an object
 * and the light sensors do not detect a line. The robot will
 * perform a biased random walk, or "wander."
 */
void wander(){
	if (irobot[iturntime] > 0) { //currently turning
		irobot[iturntime] = irobot[iturntime]-1;
		} else if (irobot[iturntime] == 0){ //stop turning
		irobot[iturntime] = -1;
	}

	if (irobot[iturntime] < 0) { //should not be turning
		if (irobot[itime]) { //wait until zero to turn
			irobot[itime] = irobot[itime]-1;
			} else { //time to turn
			if (irobot[iturn]) {
				turn_left();
				} else {
				turn_right();
			}
		}
	}

	//See if we have been turning in one direction for too long.
	if (irobot[inumturns] >= 1) { //turn back left
		irobot[iturn] = 1;
		} else if (irobot[inumturns] <= -1) { //turn back right
		irobot[iturn] = 0;
		} else { //go randomly
		irobot[iturn] = my_rand(0, 2);
	}

}

/**
 * The action to perform if the light sensors detect a line. 
 * If the left sensor sees black and right sees white then
 * the robot must turn left. If the right sensor sees black 
 * and the left sees white then the robot must turn right.
 * If both sensors see black then the robot will turn right 
 * if it is seeing black for the first time, otherwise just
 * go forward.
 */
void followLine(){
	//istate will be one of the following:
	//sensor-near: 0; w-w:1; b-b:2; w-b:3; b-w:4

	if (sensor_llight[average] <= BOUND && sensor_rlight[average] > BOUND) { //left sees black
		if(irobot[istate] != 4) {
			irobot[istatetime] = 0;
			irobot[istate] = 4;
			setMotor(0, REGSPEED);
		}
	} else if (sensor_llight[average] > BOUND && sensor_rlight[average] <= BOUND) { //right sees black
		if(irobot[istate] != 3) {
			irobot[istatetime] = 0;
			irobot[istate] = 3;
			setMotor(REGSPEED, 0);
		}
	} else {	//both see black
		if(irobot[istate] != 2) {
			//saw white-white last time
			if (irobot[istatetime] <= 1) {
				setMotor(REGSPEED, 0);
				sleep(50);
			}
		}
		//robot forward
		irobot[istatetime] = 0;
		irobot[istate] = 2;
		setMotor(REGSPEED, REGSPEED);
	}
}

/**
 * Thread that determines which action to perform, based
 * on the value of the sensors and the state of the robot.
 * First it checks if the approach object action needs to
 * be performed, as it is the one with highest priority.
 * Next it sees if both sensors see white, then the robot
 * needs to wander, otherwise it will follow a line.
 */
task movement() {
	int run = 1; //keeps track of how many loops
	int played = 0;
	while (run) {
		if (irobot[istate] == 0) {
			approachObject();
		} else if (sensor_llight[average] > BOUND && sensor_rlight[average] > BOUND) { //both see white
			if(irobot[istate] == 2) {	//if previous state was both black
				if (irobot[istatetime] <= 5) { //if it saw black-black for less than 6 cyles
					setMotor(0,REGSPEED);
					sleep(150);
				}
				irobot[istate] = 1;	
				irobot[istatetime] = 0;
			}
			if (irobot[istate] != 1) { //if the previous state was not white-white
				irobot[istate] = 1;
				irobot[istatetime] = 0;
				played = 0;
			}
			if (irobot[istate] == 1 && irobot[istatetime] > 10 && played == 0) {
				played = 1;
				playSound(soundBeepBeep);
			}
			wander();
		} 
		else { //if either sensors see black
			followLine();
		}
		irobot[istatetime] = irobot[istatetime] + 1;
		sleep(50);
		run = run + 1;
	}
}

/**
 * Initializes values to use with wander, calls the startUp
 * method and starts sensor and movement tasks. 
 */
task main(){
	int prev_turn = 0;
	count = 0;
	check_turn = 2; //left = 1, right = 0
	startTask(infrasense,kDefaultTaskPriority);
	startTask(right_lightsense,kDefaultTaskPriority);
	startTask(left_lightsense,kDefaultTaskPriority);
	startup();
	startTask(movement,kDefaultTaskPriority);

	//busy waiting loop so program does not end
	while(1);
}
